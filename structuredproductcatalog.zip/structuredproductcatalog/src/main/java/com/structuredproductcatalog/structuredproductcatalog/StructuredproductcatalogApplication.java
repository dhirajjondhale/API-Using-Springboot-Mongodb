package com.structuredproductcatalog.structuredproductcatalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StructuredproductcatalogApplication {

	public static void main(String[] args) {
		SpringApplication.run(StructuredproductcatalogApplication.class, args);
	}

}
