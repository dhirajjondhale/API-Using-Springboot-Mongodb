package com.structuredproductcatalog.structuredproductcatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StructuredproductcatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
